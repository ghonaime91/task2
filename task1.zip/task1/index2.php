
 <?php


class gg{

    function add ($a,$b){
        return $a+$b;
      
    }

    function subtraction ($a,$b){
        return $a-$b;
      
    }
    function mubtraction ($a, $b){
        return $a*$b;
      
    }
    function division ($a ,$b){
        return $a/$b;
      
    }
   }


 ?>
