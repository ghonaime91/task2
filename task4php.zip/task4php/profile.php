<?php

include 'cookies.php';
echo $_COOKIE['User'];




?>

