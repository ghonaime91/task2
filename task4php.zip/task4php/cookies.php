<?php 


setcookie('User', include 'index.php',time()+86400,'/');


   

?>